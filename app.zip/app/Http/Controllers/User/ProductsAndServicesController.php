<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Models\Admin\ProductsModel;
use App\Models\Admin\ServicesModel;
use App\Models\Users\InventoryProducts;
use App\Models\Users\ProductOrders;
use Auth;
use Carbon;
use Illuminate\Http\Request;
use JavaScript;
use Notif_Helper;
use Str;
use URL;
use Validator;

class ProductsAndServicesController extends Controller
{
    /* -------------------------------------------------------------------------- */
    /*                                Product page                                */
    /* -------------------------------------------------------------------------- */
    public function index()
    {
        /*
            * get all notification
        */

        $notif = Notif_Helper::GetUserNotification();

        /*
           * Javascript variables
        */
        JavaScript::put([
            'ruuid' => Auth::guard('web')->user()->uuid,
            'assetUrl' => asset('/'),
            'currentBaseUrl' => URL::to('/')
        ]);
        /*
            * Get all product names
        */
        $productModel = ProductsModel::orderBy('name', 'ASC');
        $productsName = $productModel->pluck('name');
        $products = $productModel->get();

        $data = array(
            'title' => 'Products | IAGD Members Lounge',
            'notif' => $notif,
            'productsName' => $productsName,
            'products' => $products
        );
        return view('pages/users/product-services/user-products', ["data" => $data]);
    }
    /* -------------------------------------------------------------------------- */
    /*                                 Get my cart                                */
    /* -------------------------------------------------------------------------- */
    public function getMyCart(Request $request)
    {
        /*
            * Check if ajax request
        */
        if (!$request->ajax()) {
            $data = [
                'status' => 'error',
                'message' => 'Invalid request!'
            ];
            return response()->json($data);
        }

        $myCart = ProductOrders::where([
            ['user_uuid','=', Auth::guard('web')->user()->uuid],
            ['status','=', 1]
        ])
            ->with('productDetails')
            ->get();

        $data = [
            'status' => 'success',
            'myCart' => $myCart
        ];
        return response()->json($data);
    }
    /* -------------------------------------------------------------------------- */
    /*                              Add to cart item                              */
    /* -------------------------------------------------------------------------- */
    public function addToCartItem(Request $request)
    {
        /*
            * Check if ajax request
        */
        if (!$request->ajax()) {
            $data = [
                'status' => 'error',
                'message' => 'Invalid request!'
            ];
            return response()->json($data);
        }

        /*
            * Validate post request
        */
        $validate = Validator::make($request->all(), [
            'uuid' => 'required',
            'quantity' => 'required|numeric',
        ], [
            'uuid.required' => 'Product id not found!',
            'quantity.required' => 'Quantity is required!',
            'quantity.numeric' => 'Quantity is not a number!',
        ]);

        /*
            * Throw validation error
        */
        if ($validate->fails()) {
            $data = [
                'status' => 'warning',
                'message' => $validate->errors()->first()
            ];
            return response()->json($data);
        }

        /*
            * Find the product
        */
        $item = ProductsModel::where('uuid', $request->input('uuid'));

        /*
            * If item not found
        */
        if ($item->count() < 1) {
            $data = [
                'status' => 'warning',
                'message' => 'Product not found!'
            ];
            return response()->json($data);
        }

        /*
            * Check if item is in the cart
        */
        $itemInCart = ProductOrders::where([
            ['product_uuid', '=', $request->input('uuid')],
            ['user_uuid', '=', Auth::guard('web')->user()->uuid],
            ['status', '=', 1]
        ]);

        if ($itemInCart->count() < 1) {
            /*
                * Insert to cart
            */
            do {
                $uuid = Str::uuid();
            } while (ProductOrders::where("uuid", $uuid)->first() instanceof ProductOrders);
            $newItem = [
                'uuid' => $uuid,
                'user_uuid' => Auth::guard('web')->user()->uuid,
                'product_uuid' => $request->input('uuid'),
                'quantity' => $request->input('quantity'),
                'status' => 1,
                'created_at' => Carbon::now(),
                'updated_at' => Carbon::now()
            ];

            $cartItem = ProductOrders::create($newItem);

            if ($cartItem->save()) {
                $data = [
                    'status' => 'success',
                    'message' => 'New product added to cart!'
                ];
                return response()->json($data);
            } else {
                $data = [
                    'status' => 'error',
                    'message' => 'Failed to add product to cart!'
                ];
                return response()->json($data);
            }
        }

        /*
            * Update item in cart
        */
        $updateCart = ProductOrders::find($itemInCart->first()->id);

        if ($item->first()->stock < ($itemInCart->first()->quantity + $request->input('quantity'))) {
            $data = [
                'status' => 'warning',
                'message' => 'Stock is not enough!'
            ];
            return response()->json($data);
        }

        $updateCart->quantity = ($itemInCart->first()->quantity + $request->input('quantity'));
        $updateCart->updated_at = Carbon::now();

        if ($updateCart->save()) {
            $data = [
                'status' => 'success',
                'message' => 'Product updated in your cart!'
            ];
            return response()->json($data);
        } else {
            $data = [
                'status' => 'error',
                'message' => 'Failed to update product in cart!'
            ];
            return response()->json($data);
        }
    }

    /* -------------------------------------------------------------------------- */
    /*                              Remove cart item                              */
    /* -------------------------------------------------------------------------- */
    public function removeItemFromCart(Request $request)
    {
        /*
            * Check if ajax request
        */
        if (!$request->ajax()) {
            $data = [
                'status' => 'error',
                'message' => 'Invalid request!'
            ];
            return response()->json($data);
        }

        /*
            * Validate post request
        */
        $validate = Validator::make($request->all(), [
            'id' => 'required',
        ], [
            'id.required' => 'ID not found!',
        ]);

        /*
            * Throw validation error
        */
        if ($validate->fails()) {
            $data = [
                'status' => 'warning',
                'message' => $validate->errors()->first()
            ];
            return response()->json($data);
        }

        /*
            * Find item in cart
        */

        $item = ProductOrders::find($request->input('id'));

        if ($item->count() < 1) {
            $data = [
                'status' => 'warning',
                'message' => 'Item not found!'
            ];
            return response()->json($data);
        }

        if (!$item->delete()) {
            $data = [
                'status' => 'warning',
                'message' => 'Failed to delete product in cart!'
            ];
            return response()->json($data);
        }

        $data = [
            'status' => 'success',
            'message' => 'Product deleted in cart!'
        ];
        return response()->json($data);
    }

    /* -------------------------------------------------------------------------- */
    /*                             Cart item checkout                             */
    /* -------------------------------------------------------------------------- */
    public function cartItemCheckout(Request $request)
    {
        /*
            * Check if ajax request
        */
        if (!$request->ajax()) {
            $data = [
                'status' => 'error',
                'message' => 'Invalid request!'
            ];
            return response()->json($data);
        }

        /*
            * Validate post request
        */
        $validate = Validator::make($request->all(), [
            'uuidArray' => 'required',
        ], [
            'uuidArray.required' => 'ID not found!',
        ]);

        /*
            * Throw validation error
        */
        if ($validate->fails()) {
            $data = [
                'status' => 'warning',
                'message' => $validate->errors()->first()
            ];
            return response()->json($data);
        }

        $jsonUuidArray = $request->input('uuidArray');
        $uuidArray = json_decode($jsonUuidArray);

        foreach ($uuidArray as $uuid) {
            $itemInCartCheckout = ProductOrders::where('uuid',$uuid);

            if ($itemInCartCheckout->count() > 0) {
                $updateCartItemStatus = ProductOrders::find($itemInCartCheckout->first()->id);

                $updateCartItemStatus->status = 2; // user has ordered

                $updateCartItemStatus->save();
            }

        }

        $data = [
            'status' => 'success',
            'message' => 'We received your order. We will verify it a soon as possible. Thank you!'
        ];
        return response()->json($data);
    }


    /* -------------------------------------------------------------------------- */
    /*                            Dog training services                           */
    /* -------------------------------------------------------------------------- */
    public function dogTrainingServices()
    {
        /*
            * get all notification
        */
        $notif = Notif_Helper::GetUserNotification();

        /*
           * Javascript variables
        */
        JavaScript::put([
            'ruuid' => Auth::guard('web')->user()->uuid,
            'assetUrl' => asset('/'),
            'currentBaseUrl' => URL::to('/')
        ]);
        /*
            * Get all product names
        */
        $servicesModel = ServicesModel::orderBy('name', 'ASC');
        $serviceNames = $servicesModel->pluck('name');
        $services = $servicesModel->get();

        $data = array(
            'title' => 'Services | IAGD Members Lounge',
            'notif' => $notif,
            'serviceNames' => $serviceNames,
            'services' => $services
        );
        return view('pages/users/product-services/user-services', ["data" => $data]);
    }

    /* -------------------------------------------------------------------------- */
    /*                          Services enrollment form                          */
    /* -------------------------------------------------------------------------- */
    public function servicesEnrollmentForm()
    {
        /*
            * get all notification
        */
        $notif = Notif_Helper::GetUserNotification();

        /*
           * Javascript variables
        */
        JavaScript::put([
            'ruuid' => Auth::guard('web')->user()->uuid,
            'assetUrl' => asset('/'),
            'currentBaseUrl' => URL::to('/')
        ]);


        $data = array(
            'title' => 'Enrollment | IAGD Members Lounge',
            'notif' => $notif,
        );
        return view('pages/users/product-services/user-services-enrollment-form', ["data" => $data]);
    }

}
