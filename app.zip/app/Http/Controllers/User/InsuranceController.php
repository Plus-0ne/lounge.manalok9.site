<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use JavaScript;
use Notif_Helper;
use Auth;
use URL;

class InsuranceController extends Controller
{
    public function index() {

        /* get all notification */
        $notif = Notif_Helper::GetUserNotification();

        /* Javascript variables */
        JavaScript::put([
            'ruuid' => Auth::guard('web')->user()->uuid,
            'assetUrl' => asset('/'),
            'currentBaseUrl' => URL::to('/')
        ]);

        $data = array(
            'title' => 'Request Insurance | IAGD Members Lounge',
            'notif' => $notif
        );

        return view('pages.users.animal-pages.user-insurance-request', ['data' => $data]);
    }
}
