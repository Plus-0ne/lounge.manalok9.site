<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Models\Users\AnimalCertRequest;
use App\Models\Users\MembersBird;
use App\Models\Users\MembersCat;
use App\Models\Users\MembersDog;
use App\Models\Users\MembersOtherAnimal;
use App\Models\Users\MembersRabbit;
use Auth;
use Carbon;
use Illuminate\Http\Request;
use JavaScript;
use Notif_Helper;
use Str;
use Validator;

class AnimalCertificationController extends Controller
{
    /* Request page load */
    public function index(Request $request)
    {
        /* Check get request */
        $validate = Validator::make($request->all(), [
            'PetUUID' => 'required'
        ], [
            'PetUUID.required' => 'Pet uuid is required'
        ]);

        if ($validate->fails()) {

            return redirect()->back()->withErrors($validate);
        }

        /* get all notification */
        $notif = Notif_Helper::GetUserNotification();

        /* Get animal details */
        $animalDetails = MembersDog::where([
            ['PetUUID', '=', $request->input('PetUUID')],
            ['OwnerUUID', '=', Auth::guard('web')->user()->uuid],
        ]);

        $AnimalType = 'dog';

        if ($animalDetails->count() < 1) {
            $animalDetails = MembersCat::where([
                ['PetUUID', '=', $request->input('PetUUID')],
                ['OwnerUUID', '=', Auth::guard('web')->user()->uuid],
            ]);
            $AnimalType = 'cat';

            if ($animalDetails->count() < 1) {
                $animalDetails = MembersRabbit::where([
                    ['PetUUID', '=', $request->input('PetUUID')],
                    ['OwnerUUID', '=', Auth::guard('web')->user()->uuid],
                ]);
                $AnimalType = 'rabbit';

                if ($animalDetails->count() < 1) {
                    $animalDetails = MembersBird::where([
                        ['PetUUID', '=', $request->input('PetUUID')],
                        ['OwnerUUID', '=', Auth::guard('web')->user()->uuid],
                    ]);
                    $AnimalType = 'bird';

                    if ($animalDetails->count() < 1) {
                        $animalDetails = MembersOtherAnimal::where([
                            ['PetUUID', '=', $request->input('PetUUID')],
                            ['OwnerUUID', '=', Auth::guard('web')->user()->uuid],
                        ]);
                        $AnimalType = 'others';
                    }
                }
            }
        }

        if ($animalDetails->count() < 1) {

            $data = [
                'status' => 'warning',
                'message' => 'Animal not found!'
            ];

            return redirect()->back()->with($data);
        }

        /* Javascript variables */
        JavaScript::put([
            'ruuid' => Auth::guard('web')->user()->uuid,
            'assetUrl' => asset('/'),
            'pet_uuid' => $request->input('PetUUID'),
            'AnimalType' => $AnimalType
        ]);

        $data = array(
            'title' => 'Request certification | IAGD Members Lounge',
            'notif' => $notif,
            'animalDetails' => $animalDetails
        );

        return view('pages.users.animal-pages.user-certification-request', ['data' => $data]);
    }

    /* -------------------------------------------------------------------------- */
    /*                        Submit certification request                        */
    /* -------------------------------------------------------------------------- */
    public function request_cert_create(Request $request)
    {
        /* Check if request is ajax */
        if (!$request->ajax()) {
            $data = [
                'status' => 'error',
                'message' => 'Something\'s wrong! Please try again later.'
            ];

            return response()->json($data);
        }

        /* Validate all request */
        $validate = Validator::make($request->all(), [
            'animalUuid' => 'required',
            'reqcertif' => 'required',
            'includepedcert' => 'required',

            'sire_name' => 'required',
            'sire_breed' => 'required',

            'dam_name' => 'required',
            'dam_breed' => 'required',

            'fb_account' => 'required',
            'animal_type' => 'required'
        ], [
            'animalUuid.required' => 'Animal uuid is required.',
            'reqcertif.required' => 'Please answer the question.',
            'includepedcert.required' => 'Please answer the question.',

            'sire_name.required' => 'Sire name is required.',
            'sire_breed.required' => 'Sire breed is required.',

            'dam_name.required' => 'Dam name is required.',
            'dam_breed.required' => 'Dam breed is required.',
            'fb_account.required' => 'Facebook account name or url is required.',
            'animal_type.required' => 'Animal type is required'
        ]);

        /* Trow validation errors */
        if ($validate->fails()) {
            $data = [
                'status' => 'error',
                'message' => $validate->errors()->first()
            ];

            return response()->json($data);
        }

        /* Check if request is no */
        if ($request->input('reqcertif') != 'yes') {
            $data = [
                'status' => 'warning',
                'message' => 'Failed to submit your request!'
            ];

            return response()->json($data);
        }

        /* Check if request exist */
        $checkRequest = AnimalCertRequest::where('animal_uuid', $request->input('animalUuid'));

        if ($checkRequest->count() > 0) {
            /* Check status */
            if ($checkRequest->first()->status != 1) { // Pending

                $data = [
                    'status' => 'warning',
                    'message' => 'You have an existing request for certification!'
                ];

                return response()->json($data);
            }

            if ($checkRequest->first()->status != 2) { // approved

                $data = [
                    'status' => 'warning',
                    'message' => 'Contact us to request new certifcation!'
                ];

                return response()->json($data);
            }
        }

        do {
            $uuid = Str::uuid();
        } while (AnimalCertRequest::where("uuid", $uuid)->first() instanceof AnimalCertRequest);

        switch ($request->input('includepedcert')) {
            case 'yes':
                $incPed = 1;
                break;

            default:
                $incPed = 0;
                break;
        }
        $insertData = [
            'uuid' => $uuid,
            'user_uuid' => Auth::guard('web')->user()->uuid,

            'animal_uuid' => $request->input('animalUuid'),
            'include_pedigree_cert' => $incPed,
            'sire_iagd_num' => $request->input('sire_iagd'),
            'sire_name' => $request->input('sire_name'),
            'sire_breed' => $request->input('sire_breed'),
            'dam_iagd_num' => $request->input('dam_iagd'),
            'dam_name' => $request->input('dam_name'),
            'dam_breed' => $request->input('dam_breed'),
            'status' => 0, // Pending
            'created_at' => Carbon::now(),
            'updated_at' => Carbon::now(),
            'fb_account' => $request->input('fb_account'),
            'animal_type' => $request->input('animal_type')
        ];
        /* Create certification request */
        $createcertRequest = AnimalCertRequest::create($insertData);

        if (!$createcertRequest->save()) {
            $data = [
                'status' => 'warning',
                'message' => 'Failed to save request! Please try again later.'
            ];

            return response()->json($data);
        }

        $data = [
            'status' => 'success',
            'message' => 'Your request for certification has been submitted.'
        ];

        return response()->json($data);
    }
}
