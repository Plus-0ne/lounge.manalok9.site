<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Admin\AdminModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

use Illuminate\Support\Facades\Validator;

use App\Models\Admin\RegistrationModel;
use Auth;

class LoungeMembersController extends Controller
{

    /* -------------------------------------------------------------------------- */
    /*                           Get admin user details                           */
    /* -------------------------------------------------------------------------- */
    public function adminUserDetails()
    {
        /* Get user details */
        $adminDetails = AdminModel::find(Auth::guard('web_admin')->user()->id)
        ->with('userAccount')
        ->first();
        return $adminDetails;
    }

	public function Lounge_Members(Request $request)
	{
        $adminDetails = $this->adminUserDetails();

		$lounge_members = RegistrationModel::where('id', '<>', NULL);

        $search = $request->input('search');
        if ($search != null) {
            $lounge_members = $lounge_members->where(function($q) use ($search) {
                $q->where('uuid', 'like', '%'. $search .'%')
                    ->orWhere('iagd_number', 'like', '%'. $search .'%')
                    ->orWhere('email_address', 'like', '%'. $search .'%')
                    ->orWhere('profile_image', 'like', '%'. $search .'%')
                    ->orWhere('first_name', 'like', '%'. $search .'%')
                    ->orWhere('last_name', 'like', '%'. $search .'%')
                    ->orWhere('middle_name', 'like', '%'. $search .'%')
                    ->orWhere('gender', 'like', '%'. $search .'%')
                    ->orWhere('birth_date', 'like', '%'. $search .'%')
                    ->orWhere('contact_number', 'like', '%'. $search .'%')
                    ->orWhere('address', 'like', '%'. $search .'%');
            });
        }

		$data = array(
			'title' => 'Lounge Members | International Animal Genetics Database',
			'lounge_members' => $lounge_members->paginate(10),
            'adminDetails' => $adminDetails,
		);

		/* GET ALL IAGD MEMBER IN IAGD MEMBER DATABASE */
		return view('pages/admins/admin-lounge-members',['data'=>$data]);
	}

}
