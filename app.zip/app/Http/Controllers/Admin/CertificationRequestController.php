<?php

namespace App\Http\Controllers\Admin;

use App\Helper\GetAdminAccount;
use App\Http\Controllers\Controller;
use App\Models\Users\AnimalCertRequest;
use Illuminate\Http\Request;
use JavaScript;
use URL;

class CertificationRequestController extends Controller
{
    /* -------------------------------------------------------------------------- */
    /*                         Certification request page                         */
    /* -------------------------------------------------------------------------- */
    public function index()
    {
        /* Get user details */
        $adminDetails = GetAdminAccount::get();

        JavaScript::put([
            'assetUrl' => asset(''),
            'currentBaseUrl' => URL::to('/')
        ]);

        $data = array(
            'title' => 'Certification Request | International Animal Genetics Database',
            'adminDetails' => $adminDetails,

        );

        return view('pages/admins/admin-certification-request', ['data' => $data]);
    }
    /* -------------------------------------------------------------------------- */
    /*                     Ajax get all certification request                     */
    /* -------------------------------------------------------------------------- */
    public function getAllCertificationRequest(Request $request)
    {
        /* Check if ajax request */
        if (!$request->ajax()) {
            $data = [
                'status' => 'error',
                'message' => 'Somethings\'s wrong! Please try again later.'
            ];
            return response()->json($data);
        }

        /* Get cetification request */
        $cert_req = AnimalCertRequest::with('requestCreator')
        ->with('animalDetails')->get();

        $data = [
            'status' => 'success',
            'message' => 'Certification request fetched.',
            'cert_req' => $cert_req
        ];
        return response()->json($data);
    }
}
