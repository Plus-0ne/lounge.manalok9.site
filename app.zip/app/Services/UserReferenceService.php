<?php

namespace App\Services;

use App\Models\Users\MembersModel;

class UserReferenceService
{
    const MAX_REFERENCES_DEPTH = 7;

    public function getUserReferences(string $iagd_number)
    {
        $user = MembersModel::where('iagd_number', $iagd_number)
            ->select('uuid', 'first_name', 'middle_name', 'last_name', 'profile_image')
            ->first();

        if (!$user) {
            return [
                'error' => [
                    'message' => 'User not found.',
                ]
            ];
        }

        $deepest_reference_level = 0;
        $total_referrals_at_each_level = array_fill(1, self::MAX_REFERENCES_DEPTH, 0);
        $user_with_most_referrals = ['iagd_number' => null, 'referrals' => 0];

        $references_array = $this->getNestedReferences($iagd_number, $deepest_reference_level, $total_referrals_at_each_level, $user_with_most_referrals, 1);

        $meta = [
            'queried_user' => $user,
            'total_references' => count($references_array),
            'deepest_reference_level' => $deepest_reference_level,
            'total_referrals_at_each_level' => $total_referrals_at_each_level,
            'user_with_most_referrals' => $user_with_most_referrals['iagd_number'],
            'timestamp' => now()
        ];

        return [
            'data' => $references_array,
            'meta' => $meta
        ];
    }

    private function getNestedReferences($iagd_number, &$deepest_reference_level, &$total_referrals_at_each_level, &$user_with_most_referrals, $level)
    {
        $references_array = [];

        if ($level > self::MAX_REFERENCES_DEPTH) {
            return $references_array;
        }

        $user_references = $this->getUserReferencesFromModel($iagd_number);
        $total_referrals = count($user_references);
        if ($total_referrals > $user_with_most_referrals['referrals']) {
            $user_with_most_referrals = ['iagd_number' => $iagd_number, 'referrals' => $total_referrals];
        }

        if ($level > $deepest_reference_level) {
            $deepest_reference_level = $level;
        }

        foreach ($user_references as $row) {
            if ($iagd_number === $row->iagd_number || $row->referred_by === null) {
                // Disallow self-checking and check if referred_by is not null
                continue;
            }
            $row->level = $level;
            $references_array[] = $row;
            $total_referrals_at_each_level[$level] += 1;
            $inner_references = $this->getNestedReferences($row->iagd_number, $deepest_reference_level, $total_referrals_at_each_level, $user_with_most_referrals, $level + 1);
            $references_array = array_merge($references_array, $inner_references);
        }

        return $references_array;
    }

    private function getUserReferencesFromModel($iagd_number)
    {
        return MembersModel::where('referred_by', $iagd_number)
                ->select('uuid', 'iagd_number', 'first_name', 'middle_name', 'last_name', 'profile_image', 'referred_by')
                ->orderBy('id', 'desc')
                ->get();
    }
}