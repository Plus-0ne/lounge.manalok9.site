<?php

namespace App\Helper;

use App\Models\Users\UserNotifications;

class UpdatePostInteraction
{
    public static function createInteraction()
    {
        /* Create new interaction using click on post , like in post , comment in post , updating posts */
    }
}
