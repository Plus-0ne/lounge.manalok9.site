<?php

namespace App\Models\Admin;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasOne;

class ServicesModel extends Model
{
    use HasFactory;

    protected $table = 'admin_services';

    protected $fillable = [
        'uuid',
        'name',
        'description',
        'price',
        'status',
        'image',
        'added_by',
        'created_at',
        'updated_at'
    ];

    /**
     * Get the inTrainingRequestCart associated with the ServicesModel
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasOne
     */
    public function inTrainingRequestCart(): HasOne
    {
        return $this->hasOne(User::class, 'foreign_key', 'local_key');
    }
}
