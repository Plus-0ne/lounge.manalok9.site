<?php

namespace App\Models\Admin;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class RegistrationRabbitModel extends Model
{
    public $timestamps = false;
    use HasFactory;

    protected $connection = 'mysql2';

    protected $table='wm_members_rabbit';
    
    protected $primaryKey = 'ID';

    protected $fillable = [
        'PetUUID',
        'OwnerUUID',
        'OwnerIAGDNo',
        
        'PetName',
        'EyeColor',
        'PetColor',
        'Markings',

        'BirthDate',
        'Location',
        'Gender',
        'Height',

        'Weight',
        'Owner',
        'SireName',
        'DamName',

        'Breed',

        'Co_Owner',

        'storage_img_uuid',
        'img_token',

        'non_member',


        'Status',
        'DateAdded',
    ];


    public function AdtlInfo()
    {
        return $this->hasOne(RegistrationPetDetailsModel::class,'PetUUID','PetUUID');
    }

    public function OwnerInfo()
    {
        return $this->setConnection('mysql')->hasOne(RegistrationModel::class,'uuid','OwnerUUID');
    }
}
