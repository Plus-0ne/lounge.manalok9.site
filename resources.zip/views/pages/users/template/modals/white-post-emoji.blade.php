<!-- Modal -->
<div class="modal" id="insert_emojiinPost" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true" data-backdrop="false">
    <div class="modal-dialog modal-md modal-dialog-centered"  style="background-color: transparent;">
        <div class="modal-content" style="background-color: transparent; width:auto;">
            <div class="d-flex justify-content-center">
                <div id="pickerNewemoji">
                </div>
            </div>
        </div>
    </div>
</div>
