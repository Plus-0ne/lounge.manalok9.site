<div class="modal fade" id="image_modal_fullscreen" tabindex="-1" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-xl">
        <div class="modal-content" style="background-color: transparent; border: none;">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-9 m-0 p-0">
                        <img class="img-full w-100" src="">
                    </div>
                    <div class="col-3 m-0 p-3" style="background-color: white;">
                        <h5>
                            Dog Name Sample
                        </h5>
                        <p>
                            Lorem ipsum dolor sit amet, consectetur adipisicing elit. Atque vitae, error iusto saepe
                            nihil tempore! Eaque, sapiente! Quasi labore, sunt quod nesciunt expedita cupiditate itaque
                            repellat quisquam delectus odio nihil.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
