{{-- Toast custom stype --}}
<style>
    .toastCustom {
        background-color: rgb(56, 56, 56);
        border-radius: 0px;
        width: auto; /* width: 100% */
    }
    .tHeaderCustom {
        background-color: rgb(56, 56, 56);
        border-radius: 0px;
        color: #fff;
    }
    .tBodyCustom {
        background-color: rgb(56, 56, 56);
        color: #fff;
    }
    .tb-image-icon {
        width: 30px;
        height: 30px;
        border-radius: 50px;
        margin-right: 6px;
    }
</style>
<div class="toast-container position-fixed bottom-0 end-0 p-3" style="z-index: 11">
</div>
