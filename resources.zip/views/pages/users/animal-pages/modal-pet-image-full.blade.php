<div id="img-preview-full-pet" class="full-page-image">
    <div class="img-pet-header">
        <button id="dlPetImage" type="button">
            <span class="mdi mdi-download"></span>
            <a id="downloadLink" style="display: none;"></a>
        </button>
        <button type="button" class="img-close-preview">
            <span class="mdi mdi-close"></span>
        </button>

    </div>
    <div class="img-pet-content">
        <img id="ipc-element" src="{{ asset('img/no_img.jpg') }}" alt="Image">
    </div>
</div>
