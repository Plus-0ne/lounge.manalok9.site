<div class="modal fade" id="searchUserModalResult" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="false" role="dialog" aria-labelledby="modalTitleId" aria-hidden="true">
    <div class="modal-dialog modal-dialog-scrollable modal-dialog-centered modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modalTitleId"><span class="mdi mdi-magnify"></span> Search results</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="s-users-results row">
                    {{-- Results container --}}
                </div>
            </div>
            <div class="modal-footer">
                {{-- <button type="button" class="btn btn-primary btn-sm">Save</button> --}}
                <div class="fs-small keyword-status-result">
                    Search "Keyword" found 100 result
                </div>
            </div>
        </div>
    </div>
</div>
